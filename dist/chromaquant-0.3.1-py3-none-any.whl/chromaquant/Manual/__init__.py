#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ChromaQuant.Manual package initialization

Julia Hancock
Created 10-18-2024

"""